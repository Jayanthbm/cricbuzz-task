[
  {
    name: "India National Cricket Team",
    teamDetails: "http://localhost:3000/api/teamDetails/1",
  },
  {
    name: "Australia National Cricket Team",
    teamDetails: "http://localhost:3000/api/teamDetails/2",
  },
];
